HAFEEZ (REX) SHOPIFY PORTFOLIO

1. Open index.html to preview the portfolio.
2. Before publishing, replace YOUR-EMAIL@example.com in index.html with your real contact email.
3. You can also replace that mailto link with your Fiverr, Contra, WhatsApp, or other public contact URL.
4. Upload the folder to a static website host to get a public https:// link.

The portfolio is responsive and needs no build step or external libraries.
